import React, { Component } from 'react'
import Modal from 'react-modal'

import './video-youtube.css'
import icoPlay from '../../../assets/images/play.png'

class ModalVideoYoutube extends Component {
    constructor(props) {
        super(props);

        this.state = {
            openModal: false
        }

        this.openModal = this.openModal.bind(this);
        this.closeModal = this.closeModal.bind(this);
    }

    openModal() {
        this.setState({ openModal: true });
    }

    closeModal() {
        this.setState({ openModal: false });
    }

    render() {
        const { modalVideoYoutube } = this.props;
        const url_video_youtube = "https://www.youtube.com/embed/" + modalVideoYoutube.snippet.resourceId.videoId

        return (
            <>
                <div className="img-traillers" onClick={this.openModal}>
                    <div className="form-group">
                    <figure className="figure">
                        <img className="img-ico-play" src={icoPlay} alt="Play" title="Play" />
                        <img src={modalVideoYoutube.snippet.thumbnails.maxres.url} className="figure-img img-fluid rounded" alt="" />
                        <figcaption className="figure-caption">{modalVideoYoutube.snippet.title}</figcaption>
                    </figure>
                    </div>

                </div>

                <Modal isOpen={this.state.openModal}
                    contentLabel={modalVideoYoutube.snippet.title}
                    ariaHideApp={false}
                >
                    <div className="embed-responsive">
                        <iframe
                            className="embed-responsive-item"
                            title={modalVideoYoutube.snippet.title}
                            src={url_video_youtube}
                            frameBorder="0"
                            allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                        />
                    </div>
                    <button onClick={this.closeModal} className="btn btn-outline-dark btnClose">Sair</button>
                </Modal>
            </>
        );
    }
}

export default ModalVideoYoutube