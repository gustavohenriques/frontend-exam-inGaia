import React, { Component } from "react";
import swal from 'sweetalert';

import './login.css'

import Logo from './../../../assets/images/logo_dark.png'
import Loader from '../../../assets/images/loader-red.gif'

class Login extends Component {
    constructor(props) {
        super(props);

        this.state = {
            username: "",
            password: "",
            isToggleOn: false,
        };
    }

    componentDidMount() {
        setTimeout(() => {
          this.setState({ isToggleOn: !this.state.isToggleOn });
        }, 2000);
    }

    carregarPage() {
        if (!this.state.isToggleOn) {
            return (
            <div className="loader-page"><img src={Loader} alt="Logo" /><div></div><div></div><div></div></div>
            );
        }
    }
    
    inputEventChange = (event) => {
        this.setState({ [event.target.name]: event.target.value })
    }

    inputEventClick = () => {
        if  (this.state.username !== null && this.state.username !== undefined && this.state.username !== "") {
            swal({
                title: "Sucesso ! :)",
                text: "você será direcionado para a página de Traillers !",
                icon: "success",
                button: "OK",
              }).then((e) => {
                  if(e) {
                    this.props.history.push("/trailers");
                  }
              });
        }
        else {
            swal({
                title: "Atenção",
                text: "por favor, preencha seu e-mail",
                icon: "warning",
                button: "OK",
            });
        }
    }

    render() {
       return (
        <>
            <div className="renderizaPage">{this.carregarPage()}</div>
            <div className="app-main full-height fixed-header nav-collapsed">
                <div className="login main-body">
                    <img src={Logo} className="img-fluid" alt="The Witcher" />
                    <div className="row col-12">
                        <form className="form-area-login">
                            <div className="form-group">
                                <input
                                    className="form-control"
                                    type="email"
                                    name="username"
                                    placeholder="Digite seu e-mail"
                                    onChange={this.inputEventChange}
                                    value={this.state.username}
                                    />
                            </div>
                            <div className="form-group">
                                <input
                                className="form-control"
                                type="password"
                                name="password"
                                placeholder="Digite sua senha"
                                onChange={this.inputEventChange}
                                value={this.state.password}
                                />
                            </div>
                            <button type="button" className="btn btn-danger" onClick={this.inputEventClick}>Logar</button>
                        </form>
                    </div>
                </div>
            </div>
        </>
        );
    }
}

export default Login;