import React, { Component } from "react";
import axios from 'axios'

// Importar Components
import ModalVideoYoutube from '../../modal/video-youtube'

// Importas Styles (.SASS, .CSS)
import './trailers.css'
// import '../login/login.css'

// Importar Logo, Thumbs, IMGs...
import Logo from './../../../assets/images/logo_dark.png'

class Trailer extends Component {
    constructor() {
        super();

        this.state = {
            isToggleOn: false,
            qtdTraillers: 6,
            qtdTraillersMax: 12,
            listChannelYouTube: []
        }
    }

    async componentDidMount() {
        setTimeout(() => {
            this.setState({ isToggleOn: !this.state.isToggleOn });
        }, 2000);

        const response = await axios.get(
            `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=30&playlistId=PL6t93nUFQQ1ZiXMfhPyhjb0PX3LgEVMcF&key=AIzaSyBtX2c5AJB7Xsayw8L0vp9Lf18c75EGzUA`
        );

        this.setState({ listChannelYouTube: response.data.items })
    }

    logout = (event) => {
        this.props.history.push("/");
    }

    leadMore = (event) => {
        this.setState({ qtdTraillers: this.state.qtdTraillersMax })
    }

    render() {

        const listaThumbsYoutube = this.state.listChannelYouTube.slice(0, this.state.qtdTraillers).map((item, index) => (
            <ModalVideoYoutube key={item.id} modalVideoYoutube={item} />
        ));

        const setButtonLeadMore = this.state.qtdTraillers <= 20 ? (
            <button className="btn btn-outline-dark" onClick={this.leadMore}>
                Lead More
            </button>
        ) : null;

        return (
            <>
                <div className="container-fluid">
                    <div className="page-trailers">
                        <div className="page-trailers-left">
                            <div className="area-menu">
                                <img src={Logo} alt="The Witcher" />
                                <div className="area-menu-buttons">
                                    <div className="navbar flex-column mt-md-0 mt-4 pt-md-0 pt-4" id="navbarWEX">
                                        <button className="btn btn-outline-dark">Traillers</button>
                                        <button className="btn btn-outline-secondary" onClick={this.logout}>
                                            Logout
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="page-trailers-right scroll">
                            <div className="row">
                                {listaThumbsYoutube}
                            </div>
                            <div className="d-flex justify-content-center button-leadmore">{setButtonLeadMore}</div>
                        </div>
                    </div>
                </div>
            </>
        )
    }
}

export default Trailer;