import React, { Component } from 'react';
import { BrowserRouter, Switch, Route } from "react-router-dom";

// importando pages (components)
import Login from '../pages/login'
import Trailer from '../pages/trailers'

// importando estilos 
import './App.css';

class App extends Component {
  render() {
    return (
      <>
        <BrowserRouter>
          <Switch>
            <Route path="/" exact component={Login} />
            <Route path="/trailers" component={Trailer} />
          </Switch>
        </BrowserRouter>
      </>
    );
  }
}

export default App;
